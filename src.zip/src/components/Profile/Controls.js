import Inputgm  from "./Inputgm"
import Radiogrp  from "./Radiogrp"

export const Controls = {
    Inputgm,
    Radiogrp
}