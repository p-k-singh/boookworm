import React,{ useState,useEffect } from "react"
import {Button} from '@material-ui/core'
import { Link } from "react-router-dom";


import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import ListItemText from '@material-ui/core/ListItemText';
import ListSubheader from '@material-ui/core/ListSubheader';
import Avatar from '@material-ui/core/Avatar';
import Paper from '@material-ui/core/Paper';

import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles((theme) => ({
    text: {
      padding: theme.spacing(2, 2, 0),
    },
    modalPaper: {
      top: '10%',
      left: '10%',
      overflow: 'scroll',
      height: '100%',
      display: 'block',
      position: 'absolute',
      //  // width: 400,
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      //   overflow:'scroll',
    },
    paper: {
  
      top: '20%',
  
      left: '20%',
      right: '10%',
      width: '60%',
      minHeight:500,
  
      display: 'block',
      position: 'absolute',
      //  // width: 400,
      backgroundColor: theme.palette.background.paper,
  
      padding: theme.spacing(2, 4, 3),
  
    },
    list: {
      marginBottom: theme.spacing(2),
    },
    subheader: {
      backgroundColor: theme.palette.background.paper,
    },
    appBar: {
      top: 'auto',
      bottom: 0,
    },
    grow: {
      flexGrow: 1,
    },
    fabButton: {
      position: 'absolute',
      zIndex: 1,
      top: -30,
      left: 0,
      right: 0,
      margin: '0 auto',
    },
  }));

const ChatIndex = (props) => {
    const classes = useStyles();
    const [chats,setChats] = useState([
        {
            userId: "abcdef",
            userName:"Prashant",
            userAvatar: "https://bookworm01.s3.ap-south-1.amazonaws.com/book-images/c5ea6570-4cfd-4551-8d2b-560d069c817d.jpg"
        },
        {
            userId: "sdsdd",
            userName:"Manu",
            userAvatar: "https://media-exp1.licdn.com/dms/image/C5103AQHMf55lswAo-g/profile-displayphoto-shrink_100_100/0/1587217987071?e=1625702400&v=beta&t=leR5trVQlj_fGdL2VZEWQX2ZOQceTVs4-AOjd91WGj8"
        }
        
    ]);
    
    const pressed = () => {
        props.client.close();
    }
    
    return(
        <div>
            <Paper square className={classes.paper}>
            <List className={classes.list}>
          {chats.map((chat, id) => {
            return (
              <React.Fragment key={id}>
                {id === 0 && <ListSubheader className={classes.subheader}>All chats</ListSubheader>}
                <ListItem button component={Link} to={`/chat/${chat.userId}`} >
                  <ListItemAvatar>
                    <Avatar alt="Profile Picture" src={chat.userAvatar} />
                  </ListItemAvatar>
                  <ListItemText primary={chat.userName} secondary={chat.description} />
                </ListItem>
              </React.Fragment>
            )

          })}
        </List>
        </Paper>
        </div>
    )
}
export default ChatIndex