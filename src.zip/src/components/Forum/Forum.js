import React from 'react'
import Gmessenger from  '../Messenger/Gmessenger'
const Forum = () => {
    return (
        <Gmessenger/>
    )
}

export default Forum
