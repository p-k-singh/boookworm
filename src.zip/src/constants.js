const constants = {
    allTags : [
       {
         label: "Action and Adventure",
         value: "Action and Adventure"
       },
       {
         label: "Classics",
         value: "Classics"
       },
       {
         label: "Comic book or Graphic Novel",
         value: "Comic book or Graphic Novel"
       },
       {
         label: "Detective and Mystery",
         value: "Detective and Mystery"
       },
       {
         label: "Fantasy",
         value: "Fantasy"
       },
       {
         label: "Historical Fiction",
         value: "Historical Fiction"
       },
       {
         label: "Horror",
         value: "Horror"
       },
       {
         label: "Literary Fiction",
         value: "Literary Fiction"
       },
       {
         label: "Romance",
         value: "Romance"
       },
       {
         label: "Science Fiction(The Testaments)",
         value: "Science Fiction(The Testaments)"
       },
       {
         label: "Short Stories",
         value: "Short Stories"
       },
       {
         label: "Suspense and Thrillers",
         value: "Suspense and Thrillers"
       },
       {
         label: "Women's Fiction",
         value: "Women's Fiction"
       },
       {
         label: "Biographies and Autobiographies",
         value: "Biographies and Autobiographies"
       },
       {
         label: "Cookbooks",
         value: "Cookbooks"
       },
       {
         label: "Essays",
         value: "Essays"
       },
       {
         label: "History",
         value: "History"
       },
       {
         label: "Memoir",
         value: "Memoir"
       },
       {
         label: "Poetry",
         value: "Poetry"
       },
       {
         label: "Self-Help",
         value: "Self-Help"
       },
       {
         label: "True Crime",
         value: "True Crime"
       }
   
     ]
}
export default constants;